This is a Basic Python Script for Ping Test which will not use any new Python Libraries

User to input the Host IP and Ping Count

Check ICMP rechability

Should work in different OS (Windows / Linux / MacOS)

Expected Result: up / down
